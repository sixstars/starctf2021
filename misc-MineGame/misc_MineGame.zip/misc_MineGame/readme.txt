MineGame:

Verify that version 9.9 (R2020b) of the MATLAB Runtime is installed.   
If not, you can run the MATLAB Runtime installer.
To find its location, enter
  
    >>mcrinstaller
      
at the MATLAB prompt.
NOTE: You will need administrator rights to run the MATLAB Runtime installer. 

Alternatively, download and install the Windows version of the MATLAB Runtime for R2020b 
from the following link on the MathWorks website:

    https://www.mathworks.com/products/compiler/mcr/index.html
   

If you can't use those ways above, you can download Runtime installer that the author has prepared for your MineGame from those site :


    https://drive.google.com/file/d/1HBxALAqETpEfT1tZSxbgMFVqv0v5pY3O/view?usp=sharing

     https://pan.baidu.com/s/130oOYBiWBwGX_HUfjuspXA    password:flag

HINT:
  1. The first time you run MineGame, it may be slow. You can try more times.
  2. Using computer with good performance may help you.





